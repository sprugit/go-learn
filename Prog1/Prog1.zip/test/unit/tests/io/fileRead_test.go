package io

import (
	"Prog1/internal/io"
	"Prog1/test/shared"
	"fmt"
	"testing"
)

func TestReadCorrectRequestsFile(t *testing.T) {

	pathToTestFile := shared.FindTestResource(
		[]string{
			"test", "unit", "data", "sample", "correct", "requests17h00.txt",
		})

	reqs, err := io.GetRequestsFile(pathToTestFile)
	if err != nil {
		t.Fatal(err)
	}

	fmt.Print(reqs.FileToString())

}

/*func TestReadIncorrectRequestsFile() {

}*/
