package intfc

type IType interface {
	getTypeName() string
}
