package intfc

type IMarshable interface {
	/* acts like a static method */
	GetTypeName() string
	FromString(entry string) (err error)
	ToEntry() string
}

/*
Note about interface types: if the struct implementing the interface
has its methods defined with (s *Struct) then, when using the interface
in generics, you need to pass the generic as *Struct for the method contract
to be Upheld, since (s Struct) doesn't uphold the contract
*/
