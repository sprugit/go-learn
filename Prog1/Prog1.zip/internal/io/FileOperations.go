package io

import "Prog1/internal/model"

func GetRequestsFile(path string) (file *EntryFile[*model.Request], err error) {
	//var obj = *new(model.Request)
	var obj model.Request
	file, err = ReadFile(path, &obj)
	return
}

func GetScheduleFile(path string) (file *EntryFile[*model.Entry], err error) {
	var obj model.Entry
	file, err = ReadFile(path, &obj)
	return
}

func GetSkippersFile(path string) (file *EntryFile[*model.Skipper], err error) {
	var obj model.Skipper
	file, err = ReadFile(path, &obj)
	return
}
