package io

import (
	"Prog1/internal/intfc"
	"Prog1/internal/model"
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const FILE_EXT = ".txt"
const TIMESTAMP_LEN = 5

type EntryFile[T intfc.IMarshable] struct {
	path     string
	filename string
	Header   *model.Header
	Entries  []T
	fileType string
}

func validateHeader(filename string, header *model.Header, filetype string) (err error) {
	var leftTrimIndex, rightTrimIndex int
	leftTrimIndex = len(filename) - (TIMESTAMP_LEN + len(FILE_EXT))
	rightTrimIndex = len(filename) - len(FILE_EXT)
	var time = filename[leftTrimIndex:rightTrimIndex]
	var timeArgs = strings.Split(time, "h")
	var hours, minutes int
	hours, err = strconv.Atoi(timeArgs[0])
	if err != nil {
		return
	}
	minutes, err = strconv.Atoi(timeArgs[1])
	if err != nil {
		return
	}
	if !(header.Timestamp.Hours == hours && header.Timestamp.Minutes == minutes) {
		err = fmt.Errorf("Input file error: time inconsistency between file name and header in file %s.", filename)
	}
	if strings.ToLower(header.FileType) != filetype {
		err = fmt.Errorf("Input file error: scope inconsistency between file name and header in file %s.", filename)
	}
	return
}

func ReadFile[T intfc.IMarshable](path string, marsh T) (file *EntryFile[T], err error) {

	var (
		header  *model.Header
		entries []T
		temp    *T
	)

	f, err := os.Open(path)
	if err != nil {
		return
	}
	scanner := bufio.NewScanner(f)
	headerStr := make([]string, 0)
	for i := 0; i < model.HeaderLines; i++ {
		scanner.Scan()
		if i == model.CompanyLine || i == model.DayLine || i == model.TimeLine ||
			i == model.FileTypeLine {
			headerStr = append(headerStr, scanner.Text())
		}
	}
	header, err = model.HeaderFromString(headerStr)
	if err != nil {
		return
	}
	err = validateHeader(f.Name(), header, marsh.GetTypeName())
	if err != nil {
		return
	}
	entries = make([]T, 0, 10) // type, int, capacity
	for scanner.Scan() {
		temp =
		err = marsh.FromString(scanner.Text())
		if err != nil {
			return
		}
		*temp = marsh
		entries = append(entries, *temp)
	}
	file = &EntryFile[T]{
		path:     path,
		filename: f.Name(),
		Header:   header,
		Entries:  entries,
		fileType: marsh.GetTypeName(),
	}
	return
}

func (entryFile *EntryFile[T]) FileToString() (contents string) {
	var entry T
	var entriesStr []string = make([]string, len(entryFile.Entries))
	for _, entry = range entryFile.Entries {
		entriesStr = append(entriesStr, entry.ToEntry())
	}
	contents = fmt.Sprintf("%s\n%s",
		entryFile.Header.ToString(),
		strings.Join(entriesStr, "\n"))
	return
}

func (entryFile *EntryFile[T]) WriteFileToPath(path string) (err error) {
	var (
		file *os.File
	)
	file, err = os.Create(path)
	if err != nil {
		return
	}
	var writer = bufio.NewWriter(file)
	_, err = writer.WriteString(entryFile.FileToString())
	return
}

func (entryFile *EntryFile[T]) WriteFile() (err error) {
	var (
		file *os.File
	)

	var path = entryFile.path
	var pathArgs = strings.Split(path, string(os.PathSeparator))
	path = strings.Join(
		pathArgs[:cap(pathArgs)],
		string(os.PathSeparator))
	var time = strings.Replace(entryFile.Header.Timestamp.TimeString(), ":", "h", 1)
	path = path + string(os.PathSeparator) + entryFile.fileType + time + FILE_EXT

	file, err = os.Create(path)
	if err != nil {
		return
	}
	var writer = bufio.NewWriter(file)
	_, err = writer.WriteString(entryFile.FileToString())
	return
}
