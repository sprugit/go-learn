package domain

import (
	"Prog1/internal/io"
	"Prog1/internal/model"
	"fmt"
	"slices"
)

const CruiseLength = 30

/*
Misread the requirements: Unused code
*/ /*
func dropCompletedAssingments(schedule *io.EntryFile[*model.Entry]) {
	var newEntries = make([]model.Entry, 10)
	for _, entry := range schedule.Entries {
		// Explicit dereference
		if entry.Timestamp.BiggerThan(schedule.Header.Timestamp) {
			newEntries = append(newEntries, *entry)
		}
	}
	schedule.Entries = &newEntries
}*/

func assignSkipper(schedule *io.EntryFile[*model.Entry],
	request *model.Request,
	skipper *model.Skipper,
	timestamp *model.DateTime) {
	var RequestName, SkipperName string
	var SkipperCost int
	RequestName = request.Name
	if skipper != nil {
		SkipperName = skipper.Name
		SkipperCost = skipper.Cost
	}
	var newEntry = model.Entry{
		Timestamp:   timestamp,
		Duration:    request.CruisePeriod,
		SkipperName: SkipperName,
		Cost:        SkipperCost,
		RequestName: RequestName,
	}
	schedule.Entries = append(schedule.Entries, &newEntry)
}

func ProcessFiles(schedule *io.EntryFile[*model.Entry],
	requests *io.EntryFile[*model.Request],
	skippers *io.EntryFile[*model.Skipper]) (err error) {

	if !(requests.Header.Timestamp.Equals(schedule.Header.Timestamp) &&
		schedule.Header.Timestamp.Equals(skippers.Header.Timestamp) &&
		skippers.Header.Timestamp.Equals(requests.Header.Timestamp)) {
		return fmt.Errorf("Input file error: time inconsistency between files.")
	}

	for _, request := range requests.Entries {
		slices.SortFunc(skippers.Entries, SortSkippers)
		var foundSkipper = false
		var timestamp model.DateTime
		timestamp = *schedule.Header.Timestamp
		for i := 0; i < len(skippers.Entries) && !foundSkipper; i++ {
			var skipper = skippers.Entries[i]
			var cLang, cSpec, cCat, cPastTime, cAccum bool
			cLang = request.Languages.HasMatch(*skipper.Language)
			cSpec = request.Specialty == skipper.Specialty
			cCat = request.Category == skipper.Category
			if cLang && cSpec && cCat {
				var RequestCruiseLengthInMinutes = CruiseLength * request.CruisePeriod
				cPastTime = skipper.Datetime.
					IsBeforeClosingTime(
						model.HourAsSeconds(RequestCruiseLengthInMinutes))
				cAccum = (skipper.AcumHours + RequestCruiseLengthInMinutes) < skipper.MaxHours
				if cPastTime && cAccum {
					foundSkipper = true
					skipper.Datetime.IncrementMinutes(RequestCruiseLengthInMinutes)
					timestamp = *skipper.Datetime // copy timestamp
					timestamp.RoundUp()
					assignSkipper(schedule, request, skipper, &timestamp)
				}
			}
		}
		if !foundSkipper {
			assignSkipper(schedule, request, nil, &timestamp)
		}
	}
	return nil
}
