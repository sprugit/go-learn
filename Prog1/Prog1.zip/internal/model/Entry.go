package model

import (
	"fmt"
	"strconv"
	"strings"
)

type Entry struct {
	Timestamp   *DateTime
	Duration    int
	SkipperName string
	Cost        int
	RequestName string
}

func (entry *Entry) ToEntry() string {
	if entry.SkipperName == "" {
		return fmt.Sprintf("%s, not-assigned, %s",
			entry.Timestamp.DateString(),
			entry.RequestName)
	}
	return fmt.Sprintf("%s, %s, %f, %s %s, %d, %s %s",
		entry.Timestamp.DateString(),
		entry.Timestamp.TimeString(),
		entry.Duration,
		entry.SkipperName,
		entry.Cost,
		entry.RequestName,
	)
}

func (e *Entry) FromString(entry string) (err error) {

	var args = strings.Split(entry, ", ")
	var datetime *DateTime
	datetime, err = DateTimeFromString(args[0], args[1])
	if err != nil {
		return
	}
	var duration int
	duration, err = strconv.Atoi(args[2])
	if err != nil {
		return
	}
	var cost int
	cost, err = strconv.Atoi(args[4])
	if err != nil {
		return
	}
	e.Timestamp = datetime
	e.Duration = duration
	e.SkipperName = args[3]
	e.Cost = cost
	e.RequestName = args[5]
	return
}

func (e *Entry) GetTypeName() string {
	return "schedule"
}
