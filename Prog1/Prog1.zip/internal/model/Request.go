package model

import (
	"fmt"
	"strconv"
	"strings"
)

type Request struct {
	Name         string
	Languages    *Language
	Category     int
	Specialty    string
	CruisePeriod int
}

// Read Write method
func (r *Request) FromString(requestline string) (err error) {
	var requestArgs = strings.Split(requestline, ", ")
	var language *Language
	language, err = LanguageFromString(requestArgs[1])
	if err != nil {
		return
	}
	var category, period int
	category, err = strconv.Atoi(strings.TrimRight(requestArgs[2], "*"))
	if err != nil {
		return
	}
	period, err = strconv.Atoi(requestArgs[4])
	if err != nil {
		return
	}
	//*r = Request{}
	r.Name = requestArgs[0]
	r.Languages = language
	r.Category = category
	r.Specialty = requestArgs[3]
	r.CruisePeriod = period
	return
}

// Read only method (r Request)
func (r Request) GetTypeName() string {
	return "requests"
}

// Read only method
func (r Request) ToEntry() string {
	return fmt.Sprintf("%s, (%s), %d, %s, %d",
		r.Name,
		r.Languages.ToEntryFormat(),
		r.Category,
		r.Specialty,
		r.CruisePeriod)
}
