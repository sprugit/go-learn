package model

import (
	"fmt"
	"strconv"
	"strings"
)

type Skipper struct {
	Name      string
	Language  *Language
	Category  int
	Cost      int
	Specialty string
	MaxHours  int
	AcumHours int
	Datetime  *DateTime
}

func (skipper *Skipper) ToEntry() string {

	return fmt.Sprintf("%s, (%s), %d*, %d, %s, %d, %d, (%s, %s)",
		skipper.Name,
		skipper.Language.ToEntryFormat(),
		skipper.Category,
		skipper.Cost,
		skipper.Specialty,
		skipper.MaxHours,
		skipper.AcumHours,
		skipper.Datetime.DateString(),
		skipper.Datetime.TimeString(),
	)
}

func (skipper *Skipper) FromString(skipperline string) (err error) {
	var skipperArgs = strings.Split(skipperline, ", ")
	var category, cost, maxhours, acumhours int
	var language *Language
	var datetime *DateTime
	language, err = LanguageFromString(skipperArgs[1])
	if err != nil {
		return
	}
	category, err = strconv.Atoi(strings.TrimRight(skipperArgs[2], "*"))
	if err != nil {
		return
	}
	cost, err = strconv.Atoi(skipperArgs[3])
	if err != nil {
		return
	}
	maxhours, err = strconv.Atoi(skipperArgs[5])
	if err != nil {
		return
	}
	acumhours, err = strconv.Atoi(skipperArgs[6])
	if err != nil {
		return
	}
	datetime, err = DateTimeFromString(skipperArgs[7], skipperArgs[8])
	if err != nil {
		return
	}
	skipper.Name = skipperArgs[0]
	skipper.Language = language
	skipper.Category = category
	skipper.Cost = cost
	skipper.Specialty = skipperArgs[4]
	skipper.MaxHours = maxhours
	skipper.AcumHours = acumhours
	skipper.Datetime = datetime
	return
}

func (s *Skipper) GetTypeName() string {
	return "skippers"
}
