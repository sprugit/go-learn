package main

import (
	"Prog1/internal/domain"
	"Prog1/internal/io"
	"Prog1/internal/model"
	"log"
	"os"
	"slices"
)

func UpdateSchedule(
	skippersFilePath string,
	scheduleFilePath string,
	requestsFilePath string) (
	skippers *io.EntryFile[*model.Skipper],
	schedule *io.EntryFile[*model.Entry],
	requests *io.EntryFile[*model.Request],
	err error) {

	skippers, err = io.GetSkippersFile(skippersFilePath)
	if err != nil {
		return
	}
	schedule, err = io.GetScheduleFile(scheduleFilePath)
	if err != nil {
		return
	}
	requests, err = io.GetRequestsFile(requestsFilePath)
	if err != nil {
		return
	}

	log.Printf("Successfully loaded files %s %s %s into memory.",
		skippersFilePath, scheduleFilePath, requestsFilePath)

	err = domain.ProcessFiles(schedule, requests, skippers)
	if err != nil {
		log.Fatal(err)
		os.Exit(1)
	}

	log.Printf("Successfully processed files.")

	slices.SortFunc(skippers.Entries, domain.SortSkippers)
	slices.SortFunc(schedule.Entries, domain.SortSchedule)

	schedule.Header.Timestamp.IncrementMinutes(30)
	skippers.Header.Timestamp.IncrementMinutes(30)
	return
}

func IfErrrorExit(err error) {
	if err != nil {
		log.Fatal(err)
		os.Exit(1)
	}
}

func main() {

	args := os.Args[1:]

	skippersFilePath := args[0]
	scheduleFilePath := args[1]
	requestsFilePath := args[2]

	var (
		_        *io.EntryFile[*model.Request] /*Requests go unused in this scope*/
		schedule *io.EntryFile[*model.Entry]
		skippers *io.EntryFile[*model.Skipper]
		err      error
	)

	skippers, schedule, _, err =
		UpdateSchedule(skippersFilePath, scheduleFilePath, requestsFilePath)
	IfErrrorExit(err)

	err = schedule.WriteFile()
	IfErrrorExit(err)

	err = skippers.WriteFile()
	IfErrrorExit(err)

	log.Printf("Successfully wrote files.")
	log.Printf("Goodbye :)")

	os.Exit(0)
}
